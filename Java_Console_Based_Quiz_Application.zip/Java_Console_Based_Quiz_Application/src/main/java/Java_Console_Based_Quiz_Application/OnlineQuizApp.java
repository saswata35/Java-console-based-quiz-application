package Java_Console_Based_Quiz_Application;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Class representing a quiz question
class Question {
    private String questionText;
    List<String> options;
    private int correctOptionIndex; // 0-based index

    public Question(String questionText, List<String> options, int correctOptionIndex) {
        this.questionText = questionText;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
    }

    public void displayQuestion() {
        System.out.println(questionText);
        for (int i = 0; i < options.size(); i++) {
            System.out.println((i + 1) + ". " + options.get(i));
        }
    }

    public boolean checkAnswer(int userChoice) {
        return (userChoice - 1) == correctOptionIndex;
    }
}

public class OnlineQuizApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Create quiz questions
        List<Question> quizQuestions = new ArrayList<>();
        quizQuestions.add(new Question(
                "What is the capital of France?",
                List.of("Berlin", "Madrid", "Paris", "Rome"),
                2 // Paris
        ));
        quizQuestions.add(new Question(
                "Which planet is known as the Red Planet?",
                List.of("Earth", "Mars", "Jupiter", "Saturn"),
                1 // Mars
        ));
        quizQuestions.add(new Question(
                "Who developed Java?",
                List.of("Microsoft", "Sun Microsystems", "Apple", "Google"),
                1 // Sun Microsystems
        ));

        int score = 0;

        System.out.println("===== Welcome to the Online Quiz App =====\n");

        // Loop through questions
        for (int i = 0; i < quizQuestions.size(); i++) {
            System.out.println("Question " + (i + 1) + ":");
            quizQuestions.get(i).displayQuestion();
            System.out.print("Enter your choice (1-" + quizQuestions.get(i).options.size() + "): ");
            int choice = sc.nextInt();

            if (quizQuestions.get(i).checkAnswer(choice)) {
                System.out.println("✅ Correct!\n");
                score++;
            } else {
                System.out.println("❌ Wrong!\n");
            }
        }

        // Display result
        System.out.println("===== Quiz Over =====");
        System.out.println("Your score: " + score + "/" + quizQuestions.size());

        sc.close();
    }
}
